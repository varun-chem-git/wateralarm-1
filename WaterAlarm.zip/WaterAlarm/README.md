# Water Alarm 💧

A simple Android app that reminds you to drink water on a repeating timer —
even when the app is closed. It shows a notification, rings/vibrates like a
real alarm, and pops up a full-screen "alarm" you have to turn off. Turning
it off shows: **"drink water cutuuuu"**.

## What it does
- Runs reminders in the background on a timer you set (e.g. every 60 min)
- Survives being swiped away — uses Android's AlarmManager, so it fires
  even if the app isn't open (and reschedules itself after each ring)
- Reschedules itself automatically after a phone restart
- Shows a high-priority notification + plays the phone's alarm sound +
  vibrates + can pop up full-screen (even over the lock screen)
- Tapping "Turn off alarm" stops the sound and shows the cute prompt

No server, Firebase, or account needed — everything runs locally on the
phone.

---

## Step 1 — Put this code on GitHub

**Option A — no git installed, just the browser:**
1. Go to github.com, log in, click **New repository** (name it e.g. `water-alarm`), keep it empty, click **Create repository**.
2. On the new repo page click **Add file → Upload files**, then drag the
   entire contents of this project folder in (keep the folder structure —
   drag the whole unzipped folder onto the page, GitHub preserves subfolders).
3. Commit directly to `main`.

**Option B — with git installed locally:**
```bash
cd WaterAlarm
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/water-alarm.git
git push -u origin main
```

## Step 2 — Let GitHub build the APK for you

The repo includes `.github/workflows/build-apk.yml`. The moment you push to
`main`, GitHub Actions will automatically:
1. Spin up a machine with Java + the Android SDK
2. Run the Gradle build
3. Upload the finished `.apk` as a downloadable build artifact

To watch/download it:
1. On your repo page, click the **Actions** tab.
2. Click the latest workflow run ("Build APK").
3. Wait for the green checkmark (first run takes ~3–5 minutes).
4. Scroll to **Artifacts** at the bottom and download `water-alarm-debug-apk`
   — it's a zip containing `app-debug.apk`.

If you ever change the code, just push again (or go to Actions → Build APK →
**Run workflow** to trigger it manually).

> Note: I can't compile Android projects myself in this environment (no
> Android SDK here), so this is written carefully but untested end-to-end.
> If the Actions build fails, open the failed step, copy the error text, and
> send it back to me — I'll fix it.

## Step 3 — Install it on the phone

1. Unzip the downloaded artifact to get `app-debug.apk`.
2. Send it to the target phone (email, Drive, Telegram, USB cable — whatever).
3. On that phone, open the file. Android will ask to allow installs from that
   source ("Install unknown apps") — allow it, then tap **Install**.
4. Open the app, set the reminder interval, tap **Start Reminders**.
5. Grant the notification permission and, if prompted, allow "exact alarms"
   for the app (Settings screen opens automatically if needed).

### For reliability, also recommend they do this:
Some phones (Xiaomi, Samsung, Oppo, etc.) aggressively kill background apps.
To make sure reminders don't get silently stopped:
- Settings → Apps → Water Alarm → Battery → set to **Unrestricted** /
  disable battery optimization for the app.

## Project structure
```
WaterAlarm/
├── app/
│   ├── build.gradle
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/waterreminder/alarm/
│       │   ├── MainActivity.kt      – set interval, start/stop
│       │   ├── AlarmReceiver.kt     – fires on schedule, shows notification
│       │   ├── AlarmSoundService.kt – plays sound + vibration
│       │   ├── AlarmActivity.kt     – full-screen "alarm ringing" screen
│       │   ├── BootReceiver.kt      – reschedules after phone restart
│       │   └── AlarmScheduler.kt    – schedule/cancel helper
│       └── res/                     – layouts, strings, icon
├── .github/workflows/build-apk.yml  – auto-builds the APK on push
└── build.gradle / settings.gradle / gradle.properties
```

## Customizing
- **Change the off-prompt message**: edit the `.setMessage(...)` line in
  `AlarmActivity.kt`.
- **Change app name**: edit `app_name` in `res/values/strings.xml`.
- **Change package name**: edit `applicationId`/`namespace` in
  `app/build.gradle` and the `com.waterreminder.alarm` folder/package path.
- **Use a custom sound** instead of the phone's default alarm tone: drop an
  mp3 into `res/raw/` and reference it in `AlarmSoundService.kt` instead of
  `RingtoneManager`.

## If you want it on the Play Store eventually
This build is a **debug APK** — perfect for sideloading onto a friend's
phone directly, but not for Play Store submission (which needs a signed
release build with a proper keystore). Happy to help set that up later if
you want to publish it properly.
