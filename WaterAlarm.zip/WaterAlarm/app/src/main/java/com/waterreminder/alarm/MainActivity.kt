package com.waterreminder.alarm

import android.Manifest
import android.app.AlarmManager
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.waterreminder.alarm.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: SharedPreferences

    private val notifPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* no-op either way, user can still use the app */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = getSharedPreferences(Prefs.NAME, MODE_PRIVATE)

        val savedInterval = prefs.getInt(Prefs.INTERVAL_MINUTES, 60)
        binding.editInterval.setText(savedInterval.toString())
        updateStatus(prefs.getBoolean(Prefs.IS_RUNNING, false))

        binding.btnStart.setOnClickListener { startReminders() }
        binding.btnStop.setOnClickListener { stopReminders() }

        requestNotificationPermissionIfNeeded()
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                notifPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    private fun canScheduleExactAlarms(): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val am = getSystemService(ALARM_SERVICE) as AlarmManager
            return am.canScheduleExactAlarms()
        }
        return true
    }

    private fun startReminders() {
        val minutes = binding.editInterval.text.toString().toIntOrNull()
        if (minutes == null || minutes < 1) {
            Toast.makeText(this, "Enter a valid number of minutes", Toast.LENGTH_SHORT).show()
            return
        }

        if (!canScheduleExactAlarms()) {
            Toast.makeText(this, "Please allow exact alarms for this app", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
            return
        }

        prefs.edit()
            .putInt(Prefs.INTERVAL_MINUTES, minutes)
            .putBoolean(Prefs.IS_RUNNING, true)
            .apply()

        AlarmScheduler.schedule(this, minutes)
        updateStatus(true)
        Toast.makeText(this, "Reminders every $minutes min started \uD83D\uDCA7", Toast.LENGTH_SHORT).show()
    }

    private fun stopReminders() {
        AlarmScheduler.cancel(this)
        prefs.edit().putBoolean(Prefs.IS_RUNNING, false).apply()
        updateStatus(false)
        Toast.makeText(this, "Reminders stopped", Toast.LENGTH_SHORT).show()
    }

    private fun updateStatus(running: Boolean) {
        binding.tvStatus.text = if (running) "Status: Running \uD83D\uDCA7" else "Status: Stopped"
    }
}
