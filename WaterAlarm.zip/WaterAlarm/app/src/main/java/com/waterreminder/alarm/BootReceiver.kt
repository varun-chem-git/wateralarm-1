package com.waterreminder.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Exact alarms are cleared when the phone reboots, so we reschedule here
 * if reminders were turned on before the reboot happened.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            val prefs = context.getSharedPreferences(Prefs.NAME, Context.MODE_PRIVATE)
            if (prefs.getBoolean(Prefs.IS_RUNNING, false)) {
                val minutes = prefs.getInt(Prefs.INTERVAL_MINUTES, 60)
                AlarmScheduler.schedule(context, minutes)
            }
        }
    }
}
