package com.waterreminder.alarm

object Prefs {
    const val NAME = "water_alarm_prefs"
    const val INTERVAL_MINUTES = "interval_minutes"
    const val IS_RUNNING = "is_running"
}
