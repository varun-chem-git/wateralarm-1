package com.waterreminder.alarm

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

/**
 * Fires when the scheduled alarm time is reached. Shows a high-priority
 * notification with a full-screen intent (so it can pop up even over the
 * lock screen, like a real alarm clock app), starts the sound/vibration
 * service, and reschedules the next reminder.
 */
class AlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        createChannel(context)

        val fullScreenIntent = Intent(context, AlarmActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val fullScreenPendingIntent = PendingIntent.getActivity(
            context, 0, fullScreenIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("Water time! \uD83D\uDCA7")
            .setContentText("Tap to drink some water")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setFullScreenIntent(fullScreenPendingIntent, true)
            .setContentIntent(fullScreenPendingIntent)
            .setAutoCancel(true)
            .build()

        val nm = ContextCompat.getSystemService(context, NotificationManager::class.java)
        nm?.notify(NOTIFICATION_ID, notification)

        ContextCompat.startForegroundService(context, Intent(context, AlarmSoundService::class.java))

        // Reschedule the next reminder if reminders are still turned on.
        val prefs = context.getSharedPreferences(Prefs.NAME, Context.MODE_PRIVATE)
        if (prefs.getBoolean(Prefs.IS_RUNNING, false)) {
            val minutes = prefs.getInt(Prefs.INTERVAL_MINUTES, 60)
            AlarmScheduler.schedule(context, minutes)
        }
    }

    companion object {
        const val CHANNEL_ID = "water_alarm_channel"
        const val NOTIFICATION_ID = 1

        fun createChannel(context: Context) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    CHANNEL_ID,
                    "Water Reminders",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Alarm reminders to drink water"
                    enableVibration(true)
                }
                val nm = context.getSystemService(NotificationManager::class.java)
                nm.createNotificationChannel(channel)
            }
        }
    }
}
